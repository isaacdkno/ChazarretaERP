import { supabase } from '../supabase';

// Función genérica para reintentar operaciones de Supabase
// Función genérica para reintentar operaciones de Supabase
async function withRetry<T>(
  operation: () => PromiseLike<any>,
  retries = 3,
  delay = 1000
): Promise<{ data: T | null; error: any }> {
  let lastError;
  for (let i = 0; i < retries; i++) {
    try {
      const result = await operation();
      if (!result.error) return { data: result.data, error: null };
      lastError = result.error;
    } catch (err) {
      lastError = err;
    }
    // Esperar antes de reintentar (exponencial backoff simple)
    await new Promise(resolve => setTimeout(resolve, delay * Math.pow(2, i)));
  }
  return { data: null, error: lastError };
}

// Ejemplo de uso: Obtener clientes
export const getCustomers = async () => {
  return await withRetry(() => supabase.from('customers').select('*'));
};

// ... (existing code)

export const getOrders = async () => {
  return await withRetry(() => 
    supabase.from('orders').select('*, order_items(*)').order('created_at', { ascending: false })
  );
};

export const getCreditNotes = async () => {
  return await withRetry(() => 
    supabase.from('credit_notes').select('*, credit_note_items(*)').order('created_at', { ascending: false })
  );
};

export const getGateEntries = async () => {
  return await withRetry(() => 
    supabase.from('gate_entries').select('*').order('created_at', { ascending: false })
  );
};
